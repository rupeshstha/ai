<footer class="app-footer">
    <div class="site-footer-right">
        <?php echo __('voyager::theme.footer_copyright'); ?> <a href="https://bikramlama.com.np" target="_blank">Bikram Lama</a>
        <?php $version = Voyager::getVersion(); ?>
        <?php if(!empty($version)): ?>
            - <?php echo e($version); ?>

        <?php endif; ?>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\personal project\NugahAdmin\vendor\tcg\voyager\src/../resources/views/partials/app-footer.blade.php ENDPATH**/ ?>