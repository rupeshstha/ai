<?php

return [
	'routes' => [
		// 'DATABASE_NAME' => 'ROUTE_NAME'
		'pages' => 'pages.show',
		'posts' => 'posts.show',
	],
	'mainStaticRoutes' => [
		'home'
	]
];